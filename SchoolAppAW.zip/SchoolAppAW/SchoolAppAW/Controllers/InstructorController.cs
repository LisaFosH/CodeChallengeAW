﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolAppAW.Models;

namespace SchoolAppAW.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class InstructorController : ControllerBase
	{
		private readonly SchoolAppAW.Data.SchoolContext _context;
		public InstructorController(SchoolAppAW.Data.SchoolContext context)
		{
			_context = context;
		}

		[HttpGet]
		public ActionResult<IEnumerable<Instructor>> GetAll()
		{
			return _context.Instructors;
		}

		[HttpDelete("{id}")]
		public async Task<ActionResult<Instructor>> DeleteInstructor(int id)
		{
			var instructor = await _context.Instructors.FindAsync(id);
			if (instructor == null)
			{
				return NotFound();
			}

			_context.Instructors.Remove(instructor);
			await _context.SaveChangesAsync();

			return instructor;
		}

		[HttpPut("{id}")]
		public async Task<IActionResult> EditInstructor(int id, Instructor instructor)
		{
			if (id != instructor.ID)
			{
				return BadRequest();
			}

			_context.Entry(instructor).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!InstructorExists(id))
				{
					return NotFound();
				}
				else
				{
					throw;
				}
			}

			return NoContent();
		}

		[HttpGet("{id}")]
		public async Task<ActionResult<Instructor>> GetInstructor(int id)
		{
			var instructor = await _context.Instructors.FindAsync(id);

			if (instructor == null)
			{
				return NotFound();
			}

			return instructor;
		}

		[HttpPost]
		public async Task<ActionResult<Instructor>> PostInstructor(Instructor instructor)
		{
			_context.Instructors.Add(instructor);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetInstructor), new { id = instructor.ID}, instructor);
		}

		public bool InstructorExists(int id)
		{
			return _context.Instructors.Any(e => e.ID == id);
		}
	}
}
