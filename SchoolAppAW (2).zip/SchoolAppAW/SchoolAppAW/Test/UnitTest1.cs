
using NUnitTestProjectSchoolAppAW;

namespace NUnitTestProjectSchoolAppAW
{	/*
	public class Tests
	{
	
		
		[Test]
		public void Task1_Test1_AddStudent()
		{
			EfMethods.AddStudent("Knut");
			CollectionAssert.AreEqual(new[] { "Knut" }, result);

			EfMethods.AddStudent("Frank");
			CollectionAssert.AreEqual(new[] { "Knut", "Frank" }, result2);
		}

		
	}
	*/
}